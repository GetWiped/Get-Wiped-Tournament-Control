# GET WIPED CONTROL Desktop

Tauri 2 Windows desktop shell for the live GET WIPED CONTROL crew center.

## Build
Install Node.js 20+ and Rust stable, then:

```bash
npm install
npm run tauri:dev
npm run tauri:build
```

Installers are generated under `src-tauri/target/release/bundle/`.

The app connects to the existing live GET WIPED backend and Discord system:
https://get-wiped-tournament.floot.app/control
