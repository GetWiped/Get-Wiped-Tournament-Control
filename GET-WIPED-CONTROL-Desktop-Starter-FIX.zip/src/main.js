const APP_URL = "https://get-wiped-tournament.floot.app/control";

// Load GET WIPED CONTROL directly as the desktop window's first-party page.
// Do not embed it in an iframe: the iframe makes the Floot auth cookie third-party
// and Windows WebView can block it, which breaks authenticated API requests.
window.location.replace(APP_URL);
